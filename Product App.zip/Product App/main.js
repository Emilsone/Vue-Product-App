var app = new Vue({
el:'#app',
data:{
    brand:'Vue Mastery',
    product: 'Socks',
    image:'./assets/green socks.jpg',
    selectedVariant:0,
    inStock:true,
    details:["80% cotton", "20% polyester", "Gender neutral"],
    variants:[
        {
        variantId: 2234,
        variantColor:"green",
        variantImage: './assets/green socks.jpg'
    },
    {
        variantId: 2235,
        variantColor:"blue",
        variantImage:'./assets/blue socks.jpg',
    }
],
    cart:0
},
methods:{
addToCart(){
    this.cart +=1
},
updateProduct(variantImage){
    this.image=variantImage
},
// computed:{
//     title(){
//       return `${this.brand}${this.product}`
//     }
// }
image(){
    return this.variants[this.selectedVariant].variantImage
}
}
})